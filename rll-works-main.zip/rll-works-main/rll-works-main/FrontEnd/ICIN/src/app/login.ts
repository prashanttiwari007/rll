export class Login {
    constructor(public emailid:String,
        public password:String,
        public role:String,
        public name:String,
        public mnumber:number,
        public gender:String,
        public dob:String,
        public city:String,
        public address:String,
        public uid:number
        ){}
}

