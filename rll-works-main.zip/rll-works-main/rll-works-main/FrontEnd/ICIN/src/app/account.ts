export class Account {
    constructor(public aid:number,
        public abalance:number,
        public anumber:number,
        public atype:String,
        public password:number,
        public uemailid:String,
        public uname:String,){}
}


