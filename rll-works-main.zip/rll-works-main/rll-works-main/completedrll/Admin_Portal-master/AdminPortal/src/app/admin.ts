export class Admin {

    public emailid:String;
    public password:String;
}
