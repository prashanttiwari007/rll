package icinTesting.ICIN_test;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Run the src/test/java" );
    }
}
