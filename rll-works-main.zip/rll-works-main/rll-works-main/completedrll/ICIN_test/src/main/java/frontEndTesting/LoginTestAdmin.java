package frontEndTesting;




public class LoginTestAdmin {
  
  public void f() {
  }
}
