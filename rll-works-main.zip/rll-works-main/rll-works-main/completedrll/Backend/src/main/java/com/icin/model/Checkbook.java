package com.icin.model;

public class Checkbook {

}
